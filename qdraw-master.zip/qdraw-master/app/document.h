#ifndef DOCUMENT_H
#define DOCUMENT_H


class Document
{
public:
    Document();


};

#endif // DOCUMENT_H
