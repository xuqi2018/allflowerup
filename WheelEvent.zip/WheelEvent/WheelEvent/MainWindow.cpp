#include "mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent)
{
	resize(1200, 800);
	sceneWidget = new QWidget(this);
	sceneWidget->setStyleSheet("border:none; background:blue;");

	sceneWidget->setFixedSize(800, 600);
	view = new QGraphicsView(sceneWidget);
	view->setStyleSheet("border:none; background:lightgray;");
	view->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
	view->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

	scene = new QGraphicsScene(sceneWidget);
	//    scene->setSceneRect(0,0,800,600);
	view->setScene(scene);
	//    view->setSceneRect(0,0,800,600);

	m_bkPixmapItem = new QGraphicsPixmapItem();
	m_bkPixmapItem->setPixmap(QPixmap("E:/WorkMark/VsDemo/WheelEvent/WheelEvent/3.bmp").scaled(1280, 960, Qt::KeepAspectRatioByExpanding));
	scene->addItem(m_bkPixmapItem);

	view->resize(800, 600);
	view->scene()->setSceneRect(0, 0, 800, 600);
	this->setCentralWidget(sceneWidget);

}

MainWindow::~MainWindow()
{

}

void MainWindow::wheelEvent(QWheelEvent *event)
{
	view->scale(1 / m_scale, 1 / m_scale);
	if (event->delta() > 0) {
		if (m_scale < 10) {
			m_scale += 0.2;
		}
		else {
			m_scale = 10;
		}
	}
	else {
		if (m_scale > 0.2) {
			m_scale -= 0.2;
		}
		else {
			m_scale = 0.2;
		}
	}
	view->scale(m_scale, m_scale);
	qDebug() << m_scale;
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
	m_lastPointF = event->pos();
}

void MainWindow::mouseMoveEvent(QMouseEvent *event)
{
	QPointF disPointF = event->pos() - m_lastPointF;
	m_lastPointF = event->pos();
	view->scene()->setSceneRect(view->scene()->sceneRect().x() + disPointF.x(), view->scene()->sceneRect().y() + disPointF.y(),
		view->scene()->sceneRect().width(), view->scene()->sceneRect().height());
	view->scene()->update();
}

void MainWindow::mouseDoubleClickEvent(QMouseEvent *event)
{

	QGraphicsPixmapItem *m_bkPixmapItem1 = new QGraphicsPixmapItem();
	m_bkPixmapItem1->setPixmap(QPixmap("E:/WorkMark/VsDemo/WheelEvent/WheelEvent/3.bmp").scaled(1280, 960, Qt::KeepAspectRatioByExpanding));
	m_bkPixmapItem1->setPos(2000, 0);
	scene->addItem(m_bkPixmapItem1);
}
