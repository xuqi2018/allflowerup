#include "MyGraphCal.h"
#include <QMouseEvent>
#include <QPaintEvent>
#include <QPainter>

MyGraphCal::MyGraphCal(QWidget *parent)
	: QMainWindow(parent) {
	ui.setupUi(this);

	ui.centralWidget->setMouseTracking(true);
	setMouseTracking(true);
}

//�������
void MyGraphCal::mousePressEvent(QMouseEvent *event) {
	switch (event->button()) {
	case Qt::LeftButton:
		bLBtnDown = true;
		selectLineSeg = nullptr;
		selectLineSeg = getSeleled();
		if (selectLineSeg != nullptr) {//ѡ���߶�
			selectLineSeg->bDraw = false;

			if (selectLineSeg->bSelStartPt) {//ѡ�����
				startPoint.setX(selectLineSeg->seg->endPoint.x);
				startPoint.setY(selectLineSeg->seg->endPoint.y);

				endPoint.setX(selectLineSeg->seg->startPoint.x);
				endPoint.setY(selectLineSeg->seg->startPoint.y);
			}
			else if (selectLineSeg->bSelEndPt) {//ѡ���յ�
				startPoint.setX(selectLineSeg->seg->startPoint.x);
				startPoint.setY(selectLineSeg->seg->startPoint.y);

				endPoint.setX(selectLineSeg->seg->endPoint.x);
				endPoint.setY(selectLineSeg->seg->endPoint.y);
			}
			else if (selectLineSeg->bSelLine) {//ѡ���߶�
				movePoint = event->pos();

				startPoint.setX(selectLineSeg->seg->startPoint.x);
				startPoint.setY(selectLineSeg->seg->startPoint.y);

				endPoint.setX(selectLineSeg->seg->endPoint.x);
				endPoint.setY(selectLineSeg->seg->endPoint.y);
			}
			update();
		}
		else {//δѡ��
			startPoint = event->pos();
			endPoint = startPoint;

			tempLine = new LINESEG;
			tempLine->seg->startPoint.x = startPoint.x();
			tempLine->seg->startPoint.y = startPoint.y();
		}
		break;
	default:
		break;
	}
}

//�ƶ����
void MyGraphCal::mouseMoveEvent(QMouseEvent *event) {
	QPointF movePt = event->pos();
	if (selectLineSeg != nullptr) {//ѡ���߶�
		if (bLBtnDown) {//��갴��
			if (selectLineSeg->bSelStartPt || selectLineSeg->bSelEndPt) {//ѡ���������յ�
				endPoint = movePt;
			}
			else if (selectLineSeg->bSelLine) {//ѡ���߶�
				double disX = movePt.x() - movePoint.x();
				double disY = movePt.y() - movePoint.y();

				startPoint.setX(startPoint.x() + disX);
				startPoint.setY(startPoint.y() + disY);

				endPoint.setX(endPoint.x() + disX);
				endPoint.setY(endPoint.y() + disY);

				movePoint = movePt;
			}
		}
	}
	else {//δѡ���߶�
		if (bLBtnDown) {
			endPoint = movePt;
		}
		else {
			selSeg(movePt);
		}
	}
	update();

}

//�ɿ����
void MyGraphCal::mouseReleaseEvent(QMouseEvent *event) {
	switch (event->button()) {
	case Qt::LeftButton:
		bLBtnDown = false;
		if (selectLineSeg != nullptr) {

			if (selectLineSeg->bSelStartPt) {//ѡ�����
				selectLineSeg->seg->startPoint.x = event->pos().x();
				selectLineSeg->seg->startPoint.y = event->pos().y();

			}
			else if (selectLineSeg->bSelEndPt) {//ѡ���յ�
				selectLineSeg->seg->endPoint.x = event->pos().x();
				selectLineSeg->seg->endPoint.y = event->pos().y();
			}
			else if (selectLineSeg->bSelLine) {//ѡ���߶�
				selectLineSeg->seg->startPoint.x = startPoint.x();
				selectLineSeg->seg->startPoint.y = startPoint.y();

				selectLineSeg->seg->endPoint.x = endPoint.x();
				selectLineSeg->seg->endPoint.y = endPoint.y();
			}
			selectLineSeg->bDraw = true;

			selectLineSeg->bSelStartPt = false;
			selectLineSeg->bSelEndPt = false;
			selectLineSeg->bSelLine = false;
			selectLineSeg = nullptr;
		}
		else {
			tempLine->seg->endPoint.x = event->pos().x();
			tempLine->seg->endPoint.y = event->pos().y();
			tempLine->bDraw = true;
			lineSegs.push_back(tempLine);
		}

		break;
	default:
		break;
	}
}

void MyGraphCal::paintEvent(QPaintEvent *event) {
	QPainter p(this);
	p.setRenderHint(QPainter::Antialiasing);

	drawLineSeg(&p);//�����߶�

	QPen pen;
	pen.setColor(QColor(255, 0, 0));
	pen.setWidth(2);
	p.setPen(pen);
	p.drawLine(startPoint, endPoint);
}

void MyGraphCal::drawLineSeg(QPainter* p) {
	QPen pen;
	pen.setColor(QColor(255, 0, 0));

	int num = lineSegs.size();
	QPointF pt1, pt2;
	for (int i = 0; i < num; i++) {
		LINESEG* oneLine = lineSegs.at(i);
		if (oneLine->bDraw) {//�Ƿ����
			pt1.setX(oneLine->seg->startPoint.x);
			pt1.setY(oneLine->seg->startPoint.y);

			pt2.setX(oneLine->seg->endPoint.x);
			pt2.setY(oneLine->seg->endPoint.y);

			if (oneLine->bSelLine || oneLine->bSelStartPt || oneLine->bSelEndPt) {//ѡ��
				pen.setWidth(4);
				p->setPen(pen);
				if (oneLine->bSelLine) {
					p->drawLine(pt1, pt2);
				}
				if (oneLine->bSelStartPt) {
					p->drawEllipse(pt1, 5, 5);
					pen.setWidth(2);
					p->setPen(pen);
					p->drawLine(pt1, pt2);
				}
				if (oneLine->bSelEndPt) {
					p->drawEllipse(pt2, 5, 5);
					pen.setWidth(2);
					p->setPen(pen);
					p->drawLine(pt1, pt2);
				}
			}
			else if (oneLine->bSelLine == false && oneLine->bSelStartPt == false && oneLine->bSelEndPt == false) {
				pen.setWidth(2);
				p->setPen(pen);
				p->drawLine(pt1, pt2);
			}
		}
	}
}

void MyGraphCal::selSeg(QPointF&pt) {
	int num = lineSegs.size();


	for (int i = 0; i < num; i++) {
		LINESEG* oneLine = lineSegs.at(i);
		LineSegment* oneLineDeg = oneLine->seg;

		PointEx ptEx(pt.x(), pt.y());
		PointEx np;//�߶��ϵĵ�
		double dis = pToLinesegDist(ptEx, *oneLineDeg, np);
		if (dis < 5 && dis >= 0.0) {
			double l = relation(np, *oneLineDeg);
			if (abs(l) < EP) {//���
				oneLine->bSelStartPt = true;
				oneLine->bSelLine = false;
				oneLine->bSelEndPt = false;
			}
			else if (abs(l - 1.0) < EP) {//�յ�
				oneLine->bSelEndPt = true;
				oneLine->bSelLine = false;
				oneLine->bSelStartPt = false;
			}
			else if (l < 1 && l > 0) {//������
				oneLine->bSelLine = true;
				oneLine->bSelEndPt = false;
				oneLine->bSelStartPt = false;
			}
		}
		else {
			oneLine->bSelLine = false;
			oneLine->bSelEndPt = false;
			oneLine->bSelStartPt = false;
		}
	}
}

MyGraphCal::LINESEG* MyGraphCal::getSeleled() {
	int num = lineSegs.size();

	for (int i = 0; i < num; i++) {
		LINESEG* oneLine = lineSegs.at(i);
		if (oneLine->bSelLine || oneLine->bSelStartPt || oneLine->bSelEndPt) {//ѡ��
			return oneLine;
		}
	}
	return nullptr;
}
