#include<QMouseEvent>
#include<QPainter>
#include<QRectF>
#include<QDebug>

#include "QtGuiGeoPointInLine.h"
#include "LineSeg.h"

QtGuiGeoPointInLine::QtGuiGeoPointInLine(QWidget *parent)
	: QMainWindow(parent) {
	//ui.setupUi(this);
	//ui.centralWidget->setMouseTracking(true);
	setMouseTracking(true);

	_pen.setStyle(Qt::SolidLine);

	_menu = new QMenu(QStringLiteral("����"));
	_action = new QAction(QStringLiteral("��"));
	connect(_action, SIGNAL(triggered()), this, SLOT(slotActionPoint()));
	_menu->addAction(_action);
	//ui.menuBar->addMenu(_menu);
}

void QtGuiGeoPointInLine::mousePressEvent(QMouseEvent *event) {

	switch (event->button()) {
	case Qt::LeftButton:
		_lbtnDown = true;
		_oneLine = new LineSeg;
		_oneLine->setStartPoint(event->localPos());
		_oneLine->setEndPoint(event->localPos());
		break;
	}
	update();
}

void QtGuiGeoPointInLine::mouseMoveEvent(QMouseEvent *event) {
	QPointF ptMove = event->localPos();

	if (_lbtnDown) {
		_oneLine->setEndPoint(ptMove);
	}
	if (_isStartPointInLine) {
		for (auto v : _lines) {
			if (isInLine(ptMove, v)) {
				v->setLineWidth(5);
			}
			else {
				v->setLineWidth(2);
			}
		}
	}
	update();
}

void QtGuiGeoPointInLine::mouseReleaseEvent(QMouseEvent *event) {
	switch (event->button()) {
	case Qt::LeftButton:
		_lbtnDown = false;
		_oneLine->setEndPoint(event->pos());
		_lines.push_back(_oneLine);
		break;
	}
	update();
}

void QtGuiGeoPointInLine::paintEvent(QPaintEvent *event) {
	QPainter painter(this);
	painter.setRenderHint(QPainter::Antialiasing, true);  //������Ⱦ,���������

	int numLine = _lines.size();
	for (auto v : _lines) {
		_pen.setColor(v->getLineColor());
		_pen.setWidth(v->getLineWidth());
		painter.setPen(_pen);
		painter.drawLine(v->getStartPoint(), v->getEndPoint());
	}
	//���Ƶ�������
	if (_lbtnDown) {
		painter.drawLine(_oneLine->getStartPoint(), _oneLine->getEndPoint());
	}
}

bool QtGuiGeoPointInLine::isInLine(QPointF&pt, LineSeg*line) {
#if 1//���ò������
	QPointF v1 = QPointF(pt.x() - line->getEndPoint().x(), pt.y() - line->getEndPoint().y());
	QPointF v2 = line->getVector();

	double v3 = v1.x()*v2.y() - v1.y()*v2.x();

	qDebug() << "v1 = " << v1 << "  v2 = " << v2 << "  v3 = " << v3;

	QRectF rect(line->getStartPoint(), line->getEndPoint());

	if (abs(v3) < 1e-8 &&rect.contains(pt.toPoint())) {
		return true;
	}
	return false;
#else//��������߶��ϣ���㵽�߶������˵�֮��ľ���͵����߶εĳ���

	double len1 = sqrt((line->getStartPoint().x() - pt.x())*(line->getStartPoint().x() - pt.x()) + (line->getStartPoint().y() - pt.y())*(line->getStartPoint().y() - pt.y()));
	double len2 = sqrt((line->getEndPoint().x() - pt.x())*(line->getEndPoint().x() - pt.x()) + (line->getEndPoint().y() - pt.y())*(line->getEndPoint().y() - pt.y()));

	double lenLine = line->getLength();
	qDebug() << "line->getLength() = " << lenLine << "  len1 + len2 = " << len1 + len2;
	if (lenLine + 0.01 >= (len1 + len2) && (len1 + len2) >= lenLine) {
		return true;
	}
	else {
		return false;
	}

#endif
}

void QtGuiGeoPointInLine::slotActionPoint() {
	_isStartPointInLine = !_isStartPointInLine;
	if (_isStartPointInLine) {
		setCursor(Qt::CrossCursor);
	}
	else {
		setCursor(Qt::ArrowCursor);
	}
}
