#pragma once

#include <QtWidgets/QMainWindow>
#include <QVector>
#include <QPen>
#include <QMenu>

//#include "ui_QtGuiGeoPointInLine.h"

class QMouseEvent;
class LineSeg;

class QtGuiGeoPointInLine : public QMainWindow {
	Q_OBJECT

public:
	QtGuiGeoPointInLine(QWidget *parent = Q_NULLPTR);
private:
	void mousePressEvent(QMouseEvent *event)override;
	void mouseMoveEvent(QMouseEvent *event)override;
	void mouseReleaseEvent(QMouseEvent *event)override;

	void paintEvent(QPaintEvent *event)override;

	bool isInLine(QPointF&pt, LineSeg*line);

private slots:
	void slotActionPoint();
private:

	QPen _pen;
	bool _lbtnDown = false;
	QVector<LineSeg*> _lines;

	LineSeg* _oneLine = nullptr;

	QMenu* _menu = nullptr;
	QAction* _action = nullptr;
	bool _isStartPointInLine = false;
};
