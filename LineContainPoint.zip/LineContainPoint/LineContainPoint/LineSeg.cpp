#include "LineSeg.h"

LineSeg::LineSeg() {
}


LineSeg::~LineSeg() {
}

QPointF LineSeg::getVector() {
	return QPointF(_ptEnd.x() - _ptStart.x(), _ptEnd.y() - _ptStart.y());
}

double LineSeg::getLength() {
	return sqrt((_ptEnd.x() - _ptStart.x())*(_ptEnd.x() - _ptStart.x()) + (_ptEnd.y() - _ptStart.y())*(_ptEnd.y() - _ptStart.y()));
}
