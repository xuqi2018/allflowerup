#pragma once
#include <QPointF>
#include <QColor>
//�߶�

class LineSeg {
public:
	LineSeg();
	~LineSeg();

	inline void setStartPoint(QPointF pt) {
		_ptStart = pt;
	}

	inline void setEndPoint(QPointF pt) {
		_ptEnd = pt;
	}

	inline QPointF&getStartPoint() {
		return _ptStart;
	}

	inline QPointF&getEndPoint() {
		return _ptEnd;
	}

	inline void setLineColor(QColor color) {
		_color = color;
	}

	inline QColor&getLineColor() {
		return _color;
	}

	inline void setLineWidth(int w) {
		_width = w;
	}
	inline int&getLineWidth() {
		return _width;
	}

	QPointF getVector();//��ȡ�߶ε�����
	double getLength();//��ȡ�߶εĳ���
private:
	QPointF _ptStart;//�߶ε����
	QPointF _ptEnd;//�߶ε��յ�

	QColor _color = QColor(255, 0, 0);
	int _width = 2;
};
