#ifndef MYSCENE_H
#define MYSCENE_H

#include <QGraphicsScene>
#include <QObject>
#include "myitem.h"
class myScene : public QGraphicsScene
{
	Q_OBJECT
public:
	myScene(QObject *parent = 0);
signals:

	void itemMoveSignal(myItem* item, const QPointF position);

protected:
	void mousePressEvent(QGraphicsSceneMouseEvent *event);
	void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);

private:

	QGraphicsItem * m_Item;
	QPointF m_oldPos;
};


#endif // MYSCENE_H