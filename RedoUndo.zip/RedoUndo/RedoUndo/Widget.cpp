#include "widget.h"
#include "ui_widget.h"
#include <QLayout>

Widget::Widget(QWidget *parent) :
	QWidget(parent),
	ui(new Ui::Widget)
{
	ui->setupUi(this);
	initAction();

	initUi();
}

Widget::~Widget()
{
	delete ui;
}

void Widget::initUi()
{
	this->setWindowTitle("��ũС��--�����س�");

	m_addItemBtn = new QPushButton();
	m_addItemBtn->setText("add Item");

	connect(m_addItemBtn, &QPushButton::clicked, this, &Widget::addItem);

	m_scene = new myScene();
	QBrush brush(Qt::gray);
	m_scene->setSceneRect(QRect(0, 0, 200, 300));
	m_scene->setBackgroundBrush(brush);

	connect(m_scene, &myScene::itemMoveSignal, this, &Widget::itemMoved);


	QGraphicsView *view = new QGraphicsView(m_scene);

	QVBoxLayout *pLayout = new QVBoxLayout();
	pLayout->addWidget(m_addItemBtn);
	pLayout->addWidget(view);


	m_undoView = new QUndoView(m_undoStack);//������ʾջ���ݵ�view(��setText���ǿյ�)
	QHBoxLayout *pHLayout = new QHBoxLayout();
	pHLayout->addLayout(pLayout);
	pHLayout->addWidget(m_undoView);


	this->setLayout(pHLayout);

	this->resize(500, 400);

}

void Widget::initAction()
{
	m_undoStack = new QUndoStack(this);//��Ų�����ջ

	m_undoAction = m_undoStack->createUndoAction(this, "Undo");
	m_undoAction->setShortcut(QKeySequence::Undo);

	m_redoAction = m_undoStack->createRedoAction(this, "Redo");
	m_redoAction->setShortcut(QKeySequence::Redo);

	this->addAction(m_undoAction);
	this->addAction(m_redoAction);
}

void Widget::addItem()
{
	QUndoCommand* add = new addCommand(m_scene);
	m_undoStack->push(add);//��ջ���� ���Զ����� addCommand �� redo

}

void Widget::itemMoved(myItem *item, QPointF pos)
{
	m_undoStack->push(new moveCommand(item, pos));//��ջ����
}