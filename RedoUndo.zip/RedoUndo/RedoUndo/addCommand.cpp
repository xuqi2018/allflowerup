#include "addcommand.h"

addCommand::addCommand(QGraphicsScene *graphicsScene, QUndoCommand *parent)
{
	m_scene = graphicsScene;

	m_item = new myItem();

	m_initPos = QPointF(10, 10); //��ʼ��item ���ɵ�λ��

	setText("add item");//undoView �оͻ���ʾ������ķ�����
}

void addCommand::redo()//stack push ʱ ���Զ�����
{
	m_scene->addItem(m_item);
	m_item->setPos(m_initPos);
	m_scene->clearSelection();
	m_scene->update();
}

void addCommand::undo()
{
	m_scene->removeItem(m_item);
	m_scene->update();
}

moveCommand::moveCommand(myItem *item, const QPointF oldPos, QUndoCommand *parent)
{
	m_item = item;

	m_newPos = m_item->pos();

	m_oldPos = oldPos;
}

void moveCommand::redo()
{
	m_item->setPos(m_newPos);
	setText(QString("Move Item:(%1,%2)").arg(m_item->pos().rx()).arg(m_item->pos().ry()));
}

void moveCommand::undo()
{
	m_item->setPos(m_oldPos);
	m_item->scene()->update();
	setText(QString("Move Item:(%1,%2)").arg(m_item->pos().rx()).arg(m_item->pos().ry()));
}