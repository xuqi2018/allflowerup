#include "myitem.h"
#include <QBrush>


myItem::myItem(QGraphicsItem *parent)
{

	m_boxItem << QPointF(0, 0) << QPointF(30, 0)
		<< QPointF(30, 30) << QPointF(0, 30)
		<< QPointF(0, 0);
	setPolygon(m_boxItem);
	//��ɫ���
	QColor color((qrand() % 256), (qrand() % 256), (qrand() % 256));

	QBrush brush(color);
	setBrush(brush);
	//���ƶ�
	setFlag(QGraphicsItem::ItemIsMovable);
	//��ѡ��
	setFlag(QGraphicsItem::ItemIsSelectable);
}
