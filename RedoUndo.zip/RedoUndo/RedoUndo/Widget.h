
#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QGraphicsView>
#include <QUndoStack>
#include <QUndoView>
#include <QAction>

#include "myscene.h"
#include "myitem.h"
#include "addCommand.h"
namespace Ui {
	class Widget;
}

class Widget : public QWidget
{
	Q_OBJECT

public:
	explicit Widget(QWidget *parent = 0);
	~Widget();

	void initUi();

	void initAction();

	void addItem();

	void itemMoved(myItem* item, QPointF pos);

private:
	Ui::Widget *ui;
	QPushButton* m_addItemBtn;
	QAction* m_undoAction;
	QAction* m_redoAction;
	myScene *m_scene;

	QUndoStack* m_undoStack;
	QUndoView* m_undoView;
};


#endif // WIDGET_H