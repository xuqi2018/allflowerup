#ifndef MYCOMMAND_H
#define MYCOMMAND_H

#include <QUndoCommand>
#include "myitem.h"
#include "myscene.h"
//����item
class addCommand :public QUndoCommand
{
public:
	addCommand(QGraphicsScene* graphicsScene, QUndoCommand* parent = 0);

	void redo() override;//��д����������
	void undo() override;
private:

	myItem* m_item;

	QGraphicsScene* m_scene;

	QPointF m_initPos;
};
//�ƶ�item
class moveCommand :public QUndoCommand
{
public:
	moveCommand(myItem* item, const QPointF oldPos, QUndoCommand* parent = 0);

	void redo() override;//��д����������
	void undo() override;
private:
	myItem* m_item;
	QPointF m_oldPos;
	QPointF m_newPos;

};


#endif // MYCOMMAND_H