#ifndef MYITEM_H
#define MYITEM_H

#include <QGraphicsItem>

class myItem :public QGraphicsPolygonItem
{

public:

	enum { Type = UserType + 1 };

	explicit myItem(QGraphicsItem *parent = 0);

	int type() const override { return Type; }
private:
	QPolygonF m_boxItem;
};



#endif // MYITEM_H
