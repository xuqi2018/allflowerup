#include "myscene.h"
#include <QGraphicsSceneMouseEvent>
#include <QDebug>

myScene::myScene(QObject *parent)
{
	m_Item = 0;

}

void myScene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
	QPointF mousePos(event->buttonDownScenePos(Qt::LeftButton).x(),
		event->buttonDownScenePos(Qt::LeftButton).y());
	const QList<QGraphicsItem* >itemList = items(mousePos);

	m_Item = itemList.isEmpty() ? 0 : itemList.first();

	if (m_Item != 0 && event->button() == Qt::LeftButton)
		m_oldPos = m_Item->pos();

	QGraphicsScene::mousePressEvent(event);

}

void myScene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
	if (m_Item != 0 && event->button() == Qt::LeftButton)
	{
		if (m_oldPos != m_Item->pos())
			//����λ���ƶ����ź�
			emit itemMoveSignal(qgraphicsitem_cast<myItem*>(m_Item), m_oldPos);
		m_Item = 0;
	}
	QGraphicsScene::mouseReleaseEvent(event);
}