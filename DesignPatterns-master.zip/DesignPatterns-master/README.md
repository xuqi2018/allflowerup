# C++ 设计模式

所有的示例都基于 VS2015，博客详情：[C++ Design Patterns](http://blog.csdn.net/u011012932/article/category/6783147 "C++ Design Patterns")

更多精彩内容，请关注微信公众号「高效程序员」，不要太惊喜哦~
